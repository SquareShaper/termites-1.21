﻿Emoji Pack - by SVOR




Thank You!


License




You're free to:
- Use these assets in both commercial and non-commercial projects.
- Modify and customize them as you like.




Restriction:
Reselling the assets, individually or as part of another pack, is not allowed.




Stay Connected




For more assets, follow us on:
- [itch.io](Svor)
-[Instagram](@SVOR87)
- [X](@SVOR87)




Feel free to DM me on Discord with any questions or feedback.




Credits




Adding "SVOR" in your project credits is appreciated but not required.




Final Note




It would make me really happy to see these assets used in your games!




- SVOR